from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('activity/', views.activity, name='activity'),
    path('purchase/', views.purchase, name='purchase'),
    path('account/', views.account, name='account'),

    path('journey/', views.journey, name='journey'),
    path('practice/', views.practice, name='practice'),
    path('practice/topic/<int:topic_id>/', views.practice_topic, name='practice_topic'),
    path('practice/start/<int:test_id>/', views.practice_start, name='practice_start'),
    path('materials/', views.materials, name='materials'),
    path('tryout/', views.tryout, name='tryout'),
]
